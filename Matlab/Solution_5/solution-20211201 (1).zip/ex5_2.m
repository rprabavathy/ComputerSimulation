N = 100000; % number of random numbers for estimate

g = @(x) exp(-2*norm(x)^2)*(norm(x)^2 + 1) * all((x<1) & (x>-1));

for D=[1 2 10 20]
   fprintf('\nD=%d\n',D);
   % normally distributed random numbers
   sig = 1/2;
   mu  = 0;
   p = @(x) 1/(sqrt(2*pi*sig^2)^D) * exp(-(norm(x)-mu)^2 / (2*sig^2));
   f = @(x) g(x)/p(x);
   
   I = zeros(N,1);
   for l=1:N
      x= randn(D,1)*sig+mu; % vector with normal random numbers in -1..+1
      I(l) = f(x);
   end
   mI = mean(I);
   dI = std(I)/sqrt(N);
   fprintf('result using uniform random numbers: %f +/- %f\n',mI,dI);
   
   if D==1
      % plot the function
      figure(1);
      xx=linspace(-1,+1,200);
      yy=arrayfun(g,xx);
      plot(xx,yy,'k-');
      xlabel('x');
      ylabel('g(x)');
      % vectorized version of g
      gv = @(x) arrayfun(g,x);
      % compute integral using MATLAB's numerical integration routine
      Imlab = quad(gv,-1,+1);
      fprintf('exact: %f\n',Imlab);
   end
   
   if D==2
      % vectorized 2d version of g
      gv = @(x,y) arrayfun(@(x1,x2) g([x1;x2]), x, y);
      
      % plot the function
      figure(2);
      xx =linspace(-1,+1,30);
      [xx,yy] = meshgrid(xx);
      zz = gv(xx,yy);
      surf(xx,yy,zz);
      xlabel('x_1');
      ylabel('x_2');
      zlabel('g(x)');
      % compute integral using MATLAB's numerical integration routine
      Imlab = quad2d(gv,-1,+1,-1,+1);
      fprintf('exact: %e\n',Imlab);
   end
end