function [ l ] = lexic( x )
global L;

 [s,s1]= size(x);
l = x(1)+L*(x(2)-1);
  
end

